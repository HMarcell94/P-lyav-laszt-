﻿namespace FullCateringApi.Exceptions
{
    public class BadUsernameOrPasswordException : Exception
    {
    }
}
