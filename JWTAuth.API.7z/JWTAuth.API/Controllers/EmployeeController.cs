using Microsoft.AspNetCore.Mvc;
  using JWTAuth.API.Dto;
    using JWTAuth.API.Interfaces;
    using JWTAuth.API.Data.Entitites;
using System.Collections.Generic;
using System.Linq;

namespace Palyavalaszto.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : Controller
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        [HttpGet]
        [ProducesResponseType(200, Type = typeof(IEnumerable<employee>))]
        public IActionResult GetEmployees()
        {
            var employees = _employeeRepository.GetEmployees().Select(e => new EmployeeDto
            {
                EmployeeID = e.EmployeeID,
                UserID = e.UserID,           
                ContactNumber = e.ContactNumber,
                Portfolio = e.Portfolio,
                Resume = e.Resume

            }).ToList();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(employees);
        }

        [HttpGet("{employeeId}")]
        [ProducesResponseType(200, Type = typeof(employee))]
        [ProducesResponseType(400)]
        public IActionResult GetEmployee(int employeeId)
        {
            if (!_employeeRepository.EmployeeExists(employeeId))
                return NotFound();

            var employee = _employeeRepository.GetEmployee(employeeId);
            var employeeDto = new EmployeeDto
            {
                EmployeeID = employee.EmployeeID,
                UserID = employee.UserID,
                ContactNumber = employee.ContactNumber,
                Portfolio = employee.Portfolio,
                Resume = employee.Resume
            };

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(employeeDto);
        }

        [HttpPost]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        public IActionResult CreateEmployee([FromBody] EmployeeDto employeeCreate)
        {
            if (employeeCreate == null)
                return BadRequest(ModelState);

            var employee = _employeeRepository.GetEmployees()
                    .Where(e => e.EmployeeID == employeeCreate.EmployeeID)
                    .FirstOrDefault();

            if (employee != null)
            {
                ModelState.AddModelError("", "Employee already exists");
                return StatusCode(422, ModelState);
            }

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var employeeEntity = new employee
            {
                EmployeeID = employeeCreate.EmployeeID,
                UserID = employeeCreate.UserID,
                ContactNumber = employeeCreate.ContactNumber,
                Portfolio = employeeCreate.Portfolio,
               Resume = employeeCreate.Resume
            };

            if (!_employeeRepository.CreateEmployee(employeeEntity))
            {
                ModelState.AddModelError("", "Something went wrong while saving the employee");
                return StatusCode(500, ModelState);
            }

            return Ok("Successfully created");
        }

        [HttpPut("{employeeId}")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult UpdateEmployee(int employeeId, [FromBody] EmployeeDto updatedEmployee)
        {
            if (updatedEmployee == null)
                return BadRequest(ModelState);

            if (employeeId != updatedEmployee.EmployeeID)
                return BadRequest(ModelState);

            if (!_employeeRepository.EmployeeExists(employeeId))
                return NotFound();

            if (!ModelState.IsValid)
                return BadRequest();

            var employeeEntity = _employeeRepository.GetEmployee(employeeId);

            employeeEntity.UserID = updatedEmployee.UserID;
            employeeEntity.ContactNumber = updatedEmployee.ContactNumber;
            employeeEntity.Portfolio = updatedEmployee.Portfolio;
            employeeEntity.Resume = updatedEmployee.Resume;

            if (!_employeeRepository.UpdateEmployee(employeeEntity))
            {
                ModelState.AddModelError("", "Something went wrong while updating the employee");
                return StatusCode(500, ModelState);
            }

            return Ok("Successfully updated");
        }
    }
}
