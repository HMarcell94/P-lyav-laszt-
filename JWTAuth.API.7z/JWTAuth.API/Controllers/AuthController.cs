﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using JWTAuth.API.Exceptions;
using JWTAuth.API.Data.Entitites;
using JWTAuth.API.Services;
namespace JWTAuth.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        MyWorldDbContext _sql;
        IAuthenticationService _authService;

        public AuthController(MyWorldDbContext sql, IAuthenticationService UserService)
        {
            this._sql = sql;
            UserService = UserService;
        }


        [HttpPut("Registration")]
        public async Task<IActionResult> CreateUser([FromBody] RegistrationRequest reg)
        {
            GenericResponse<RegistrationResponse> response = new GenericResponse<RegistrationResponse>();
            try
            {
                _USer(reg);
                return Ok(response);
            }
            catch (Exception ex)
            {

            }
            return BadRequest(response);
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest login)
        {
            GenericResponse<LoginResponse> response = new GenericResponse<LoginResponse>();
            try
            {
                response.Data = await this(login);
                return Ok(response);
            }
            catch (BadUsernameOrPasswordException)  
            {
                response.QueryIsSuccess = false;
                response.Message = "Hibás felhasználónév vagy jelszó!";
            }
            catch (Exception ex)
            {
                response.QueryIsSuccess = false;
                response.Message = ex.Message;
            }
            return BadRequest(response);
        }

    }
}

