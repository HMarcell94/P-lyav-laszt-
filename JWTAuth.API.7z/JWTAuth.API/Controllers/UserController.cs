﻿using JWTAuth.API.Data.Entitites;
using JWTAuth.API.Dtos;
using JWTAuth.API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JWTAuth.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
         public UserController(IUserService userService) 
        {
        _userService = userService;
        }
        [HttpPost("register")]
        public async Task<IActionResult> UserRegistration(UserRegistrationDto userRegistration)
        {
            var result = await _userService.RegisterNewUserAsync(userRegistration);
            if(result.isUserRegistered) 
            {
            
            return Ok(result.Message);
            }
            ModelState.AddModelError("Email",result.Message);
            return BadRequest(ModelState);

        }
    }
}
