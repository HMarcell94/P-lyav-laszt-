using System.Linq;
using JWTAuth.API.Data.Entitites;
using JWTAuth.API.Interfaces;
using JWTAuth.API.Services;
using Microsoft.EntityFrameworkCore;


namespace JWTAuth.API.Repository
{
    public class EmployerRepository : IEmployerRepository
    {
        private MyWorldDbContext _context;
        public EmployerRepository(MyWorldDbContext context)
        {
            _context = context;
        }
        public bool EmployerExists(int id)
        {
            return _context.Employers.Any(e => e.EmployerID == id);
        }

        public bool CreateEmployer(employer employer)
        {
            _context.Employers.Add(employer);
            return Save();
        }

        public bool DeleteEmployer(employer employer)
        {
            _context.Employers.Remove(employer);
            return Save();
        }

        public ICollection<employer> GetEmployers()
        {
            return _context.Employers.ToList();
        }

        public employer GetEmployer(int id)
        {
            return _context.Employers.Where(e => e.EmployerID == id).FirstOrDefault();
        }

        public ICollection<user> GetUsersByEmployer(int employerId)
        {
            return _context.users.Where(u => u.UserID == employerId).ToList();
        }

        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public bool UpdateEmployer(employer employer)
        {
            _context.Employers.Update(employer);
            return Save();
        }
     

        public ICollection<job> GetJobsByEmployer(int employerId)
        {
            throw new NotImplementedException();
        }
    }
}
