using System.Linq;
using JWTAuth.API.Data.Entitites;
using JWTAuth.API.Interfaces;
using JWTAuth.API.Services;
using Microsoft.EntityFrameworkCore;

namespace JWTAuth.API.Repository
{
    public class ApplicationRepository : IApplicationRepository
    {
        private MyWorldDbContext _context;
        public ApplicationRepository(MyWorldDbContext context)
        {
            _context = context;
        }
        public bool ApplicationExists(int id)
        {
            return _context.application.Any(a => a.ApplicationID == id);
        }

        public bool CreateApplication(applications application)
        {
            _context.application.Add(application);
            return Save();
        }

        public bool DeleteApplication(applications application)
        {
            _context.application.Remove(application);
            return Save();
        }

        public ICollection<applications> GetApplications()
        {
            return _context.application.ToList();
        }

        public applications GetApplication(int id)
        {
            return _context.application.Where(a => a.ApplicationID == id).FirstOrDefault();
        }

        public ICollection<job> GetJobsByApplication(int applicationId)
        {
            return _context.Jobs.Where(j => j.JobID == applicationId).ToList();
        }

        public ICollection<employee> GetEmployeesByApplication(int applicationId)
        {
            return _context.Employees.Where(e => e.EmployeeID == applicationId).ToList();
        }

        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public bool UpdateApplication(applications application)
        {
            _context.application.Update(application);
            return Save();
        }
    }
}
