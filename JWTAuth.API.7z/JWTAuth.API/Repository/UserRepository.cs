using System.Linq;
using JWTAuth.API.Data.Entitites;
using JWTAuth.API.Interfaces;
using JWTAuth.API.Services;
using Microsoft.EntityFrameworkCore;


namespace JWTAuth.API.Repository
{
    public class UserRepository : IUserRepository
    {
        private MyWorldDbContext _context;
        public UserRepository(MyWorldDbContext context)
        {
            _context = context;
        }
        public bool UserExists(int id)
        {
            return _context.users.Any(u => u.UserID == id);
        }

        public bool CreateUser(user users)
        {
            _context.users.Add(users);
            return Save();
        }

        public bool DeleteUser(user users)
        {
            _context.users.Remove(users);
            return Save();
        }

        public ICollection<user> GetUsers()
        {
            return _context.users.ToList();
        }

        public user GetUser(int id)
        {
            return _context.users.Where(u => u.UserID == id).FirstOrDefault();
        }

        public ICollection<employee> GetEmployeesByUser(int userId)
        {
            return _context.Employees.Where(e => e.UserID == userId).ToList();
        }

        public ICollection<employer> GetEmployersByUser(int userId)
        {
            return _context.Employers.Where(e => e.UserID == userId).ToList();
        }

        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public bool UpdateUser(user users)
        {
            _context.users.Update(users);
            return Save();
        }
           public bool DeleteUse(user user)
        {
            _context.users.Remove(user);
            return Save();
        }
        
    }
}
