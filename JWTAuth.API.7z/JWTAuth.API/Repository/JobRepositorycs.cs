using System.Linq;
using JWTAuth.API.Data.Entitites;
using JWTAuth.API.Interfaces;
using JWTAuth.API.Services;
using Microsoft.EntityFrameworkCore;


namespace JWTAuth.API.Repository
{
    public class JobRepository : IJobRepository
    {
        private MyWorldDbContext _context;
        public JobRepository(MyWorldDbContext context)
        {
            _context = context;
        }
        public bool JobExists(int id)
        {
            return _context.Jobs.Any(j => j.JobID == id);
        }

        public bool CreateJob(job job)
        {
            _context.Jobs.Add(job);
            return Save();
        }

        public bool DeleteJob(job job)
        {
            _context.Jobs.Remove(job);
            return Save();
        }

        public ICollection<job> GetJobs()
        {
            return _context.Jobs.ToList();
        }

        public job GetJob(int id)
        {
            return _context.Jobs.Where(j => j.JobID == id).FirstOrDefault();
        }

        public ICollection<employer> GetEmployersByJob(int jobId)
        {
            return _context.Jobs.Where(j => j.JobID == jobId).Select(j => j.employer).ToList();
        }

        public ICollection<applications> GetApplicationsByJob(int jobId)
        {
            return _context.application.Where(a => a.JobID == jobId).ToList();
        }

        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public bool UpdateJob(job job)
        {
            _context.Jobs.Update(job);
            return Save();
        }
    }
}
