﻿namespace JWTAuth.API.Interfaces;

public interface IVATService
{
    public Task AddVAT(VAT VAT);

    public Task RemoveVAT(int id);

    public VAT GetVAT(int id);

    public Task UpdateVAT(VAT VAT);

    public List<VAT> GetAllVAT();

}
