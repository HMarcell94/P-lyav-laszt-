﻿using FullCateringApi.Objects;
using System.ComponentModel.DataAnnotations;

namespace JWTAuth.API.Interfaces
{
    public class IValidatorService
    {
        public interface IValidationService
        {
            ValidItem Validate<T>(T item);
        }
    }
}
