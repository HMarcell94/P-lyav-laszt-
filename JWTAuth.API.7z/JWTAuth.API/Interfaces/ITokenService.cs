﻿using JWTAuth.API.Data.Entitites;

namespace JWTAuth.API.Interfaces
{
    public interface ITokenService
    {
        string CreateToken(user user);
    }
}
