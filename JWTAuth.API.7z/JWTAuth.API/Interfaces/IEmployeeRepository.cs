using System.Collections.Generic;
using JWTAuth.API.Data.Entitites;

namespace JWTAuth.API.Interfaces
{
    public interface IEmployeeRepository
    {
        ICollection<employee> GetEmployees();
        employee GetEmployee(int id);
        ICollection<user> GetUsersByEmployee(int employeeId);
        ICollection<applications> GetApplicationsByEmployee(int employeeId);
        bool EmployeeExists(int id);
        bool CreateEmployee(employee employee);
        bool UpdateEmployee(employee employee);
        bool DeleteEmployee(employee employee);
        bool Save();
    }
}
