﻿using JWTAuth.API.Data.Entitites;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;

namespace JWTAuth.API.Interfaces
{
    public interface IAuthService
    {
        bool IsAuthenticated { get; }
        user CurrentUser { get; }
        Task<LoginResponse> Logon(LoginRequest login);
        Task<RegistrationResponse> Registration(RegistrationRequest reg);
    }
}
