    using JWTAuth.API.Dtos;
    using JWTAuth.API.Data.Entitites;
using System.Security.Cryptography;

namespace JWTAuth.API.Services
    {
        public class UserService : IUserService
        {
            private readonly MyWorldDbContext _worldDbContext;
    public UserService(MyWorldDbContext worldDbContext)
    {
    _worldDbContext = worldDbContext;


    }

    private users FromUserRegistrationModelToUserMode(UserRegistrationDto userRegistration )
    {
    return new users{
        Email = userRegistration.Email,
        Username =userRegistration.Username,
        Password = userRegistration.Password
    };
        
    }
    private string HashPassword(string plainPassword)
    {
        byte[] salt = new byte[16];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

var rfcPassword = new Rfc2898DeriveBytes(plainPassword,salt,1000, HashAlgorithmName.SHA1);
            byte[] rfcPasswordHash = rfcPassword.GetBytes(28);

            byte[] passwordHash = new byte[36];
            Array.Copy(salt,0, passwordHash, 0, 16);
            Array.Copy(rfcPasswordHash, 0, passwordHash, 16, 20);
            
            return Convert.ToBase64String(passwordHash);


        }
            public async Task<(bool isUserRegistered, string Message)> RegisterNewUserAsync(UserRegistrationDto userRegistration)
            {
            var isUserExist = _worldDbContext.users.Any(_=>_.Email.ToLower()==userRegistration.Email.ToLower());
            if(isUserExist)
            {
    return(false, "Az Email cím már létezik");

            }
            var newUser = FromUserRegistrationModelToUserMode(userRegistration);
            newUser.Password = HashPassword(newUser.Password);
            _worldDbContext.users.Add(newUser);
            _worldDbContext.SaveChanges();
            return (true, "Siker");
            }
        }


    }