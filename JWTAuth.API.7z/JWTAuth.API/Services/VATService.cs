﻿using JWTAuth.API.Controllers;
using JWTAuth.API.Exceptions;
using Microsoft.AspNetCore.Mvc;

namespace FullCateringApi.Services;

public class VATService : IVATService
{
    private SQL _sql;

    public VATService(SQL sql)
    {
        _sql = sql;
    }

    public async Task AddVAT(VAT VAT)
    {
        _sql.VATs.Add(VAT);
        await _sql.SaveChangesAsync();
    }

    public async Task RemoveVAT(int id)
    {
        if (!_sql.VATs.Any(x => x.Id == id)) throw new ItemNotFoundException();
        _sql.VATs.Remove(_sql.VATs.Single(x => x.Id == id));
        await _sql.SaveChangesAsync();
    }

    public VAT GetVAT(int id)
    {
        if (!_sql.VATs.Any(x => x.Id == id)) throw new ItemNotFoundException();
        var VAT = _sql.VATs.Single(x => x.Id == id);
        return VAT;
    }

    public async Task UpdateVAT(VAT VAT)
    {
        if (_sql.VATs.Any(x => x.Id == VAT.Id)) throw new ItemNotFoundException();
        _sql.VATs.Update(VAT);
        await _sql.SaveChangesAsync();
    }

    public List<VAT> GetAllVAT()
    {
        return _sql.VATs.ToList();
    }




}
