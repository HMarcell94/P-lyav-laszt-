﻿using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace JWTAuth.API.Services
{
    public class ValidationService : IValidationService
    {
        public ValidItem Validate<T>(T item)
        {
            ValidItem validItem = new ValidItem();
            List<string> memberErrors = new List<string>();
            PropertyInfo[] props = typeof(T).GetProperties();
            foreach (PropertyInfo p in props)
            {
                if (Attribute.IsDefined(p, typeof(RequiredAttribute)))
                {
                    if (p.GetValue(item) == null)
                    {
                        validItem.Status = EValidStatus.Invalid;
                        memberErrors.Add(p.Name);
                    }
                }
            }
            return validItem;
        }
    }
}
