
using JWTAuth.API.Dtos;
using System.Threading.Tasks;

namespace JWTAuth.API.Services
{
    public interface IUserService
    {
        Task<(bool isUserRegistered, string Message)> RegisterNewUserAsync(UserRegistrationDto userRegistration, bool value);

        Task<(bool isUserLoggedIn, string Message)> LoginUserAsync(UserLoginDto userLogin);
    }
   

}


