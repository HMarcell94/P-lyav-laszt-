using JWTAuth.API.Dtos;
namespace JWTAuth.API.Services
{
public interface IUserService
{
 public Task<(bool isUserRegistered, string Message)> RegisterNewUserAsync(UserRegistrationDto userRegistration);


}

}