namespace JWTAuth.API.Dto
{
    public class EmployeeDto
    {
        public int EmployeeID { get; set; }

        public int? UserID { get; set; }

        public string ContactNumber { get; set; }

        public string Resume { get; set; }

        public string Portfolio { get; set; }
    }
}