namespace JWTAuth.API.Dto
{
    public class EmployerDto
    {
        public int EmployerID { get; set; }

        public int? UserID { get; set; }

        public string CompanyName { get; set; }

        public string CompanyDescription { get; set; }
        
        public string? CompanyLogo { get; set; }
    }
}