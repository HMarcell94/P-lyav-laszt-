namespace JWTAuth.API.Dto
{
    public class RoleDto
    {
        public int RoleID { get; set; }

        public string RoleName { get; set; }
    }
}