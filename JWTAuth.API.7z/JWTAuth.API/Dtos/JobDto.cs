namespace JWTAuth.API.Dto
{
    public class JobDto
    {
        public int JobID { get; set; }

        public int? EmployerID { get; set; }

        public string? JobTitle { get; set; }

        public string? JobDescription { get; set; }

        public string? JobRequirements { get; set; }

        public string? JobLocation { get; set; }

        public decimal? JobSalary { get; set; }
        public string picture {get; set;}
    }
}
