﻿

namespace FullCateringApi.Objects
{
	public class ValidItem
	{
		public EValidStatus Status { get; set; } = EValidStatus.Valid;
		public IEnumerable<string> InvalidFields { get; set; } =new List<string>();
	}
}
