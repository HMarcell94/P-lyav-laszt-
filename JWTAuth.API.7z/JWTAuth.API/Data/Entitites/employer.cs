using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

        namespace JWTAuth.API.Data.Entitites
{
    [Table("employers")]
    public  class employer
    {
        [Key]
        [Required]
        public int EmployerID { get; set; }

        public int? UserID { get; set; }

        public user user { get; set; }

        public string CompanyName { get; set; }

        public string CompanyDescription { get; set; }

        public string? CompanyLogo { get; set; }

        public ICollection<job> jobs { get; set; }

    }
}