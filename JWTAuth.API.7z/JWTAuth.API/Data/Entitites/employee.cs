using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


        namespace JWTAuth.API.Data.Entitites
{
    [Table("employees")]
 
    public  class employee
    {
        [Key]
        [Required]
        public int EmployeeID { get; set; }

        public int? UserID { get; set; }

        public user user { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string ContactNumber { get; set; }

        public string? Portfolio { get; set; }

        public string? Resume { get; set; }

        public ICollection<applications> applications { get; set; }

    }
}