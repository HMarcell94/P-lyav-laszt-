using JWTAuth.API.Data.Entitites;
using Microsoft.EntityFrameworkCore;
namespace JWTAuth.API.Data.Entitites
{
    public class MyWorldDbContext:DbContext
    {
        public MyWorldDbContext(DbContextOptions<MyWorldDbContext> options):base(options)
        {

        }
        public DbSet<users> users{get;set;}

    }
}
