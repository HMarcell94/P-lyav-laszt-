﻿namespace PalyavalsztoBackEnd.Enums
{
    public enum EValidStatus
    {
        Invalid = 0,
        Valid = 1
    }
}
