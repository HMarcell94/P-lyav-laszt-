﻿using DB_Module.Models;
using DB_Module;
using PalyavalsztoBackEnd.Exceptions;
using Microsoft.AspNetCore.Mvc;
using System;
using DB_Module.Models;

namespace PalyavalsztoBackEnd.Services
{
    public class UserService : IUser
    {
        private SQL _sql;

        public UserService(SQL sql)
        {
            _sql = sql;
        }

        public async Task AddUser(User user)
        {
            _sql.Users.Add(user);
            await _sql.SaveChangesAsync();
        }

        public User GetUser(Guid id)
        {
            if (!_sql.Users.Any(x => x.Id == id)) throw new ItemNotFoundException();
            var user = _sql.Users.Single(x => x.Id == id);
            return user;
        }

        public User[] GetAllUsers()
        {
            return _sql.Users.ToArray();
        }

        public async Task UpdateUser(User user)
        {
            if (!_sql.Users.Any(x => x.Id == user.Id)) throw new ItemNotFoundException();
            _sql.Users.Update(user);
            await _sql.SaveChangesAsync();
        }

        public async Task DisableUser(Guid id)
        {
            var user = _sql.Users.Single(x => x.Id == id);
            if (user == null) throw new ItemNotFoundException();
            user.Enabled = false;
            _sql.Users.Update(user);
            await _sql.SaveChangesAsync();
        }

        public async Task EnableUser(Guid id)
        {
            var user = _sql.Users.Single(x => x.Id == id);
            if (user == null) throw new ItemNotFoundException();
            user.Enabled = true;
            _sql.Users.Update(user);
            await _sql.SaveChangesAsync();
        }
    }
}
