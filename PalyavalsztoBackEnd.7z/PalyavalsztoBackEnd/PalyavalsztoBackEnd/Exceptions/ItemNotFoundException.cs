﻿namespace PalyavalsztoBackEnd.Exceptions;

public class ItemNotFoundException : Exception
{

}