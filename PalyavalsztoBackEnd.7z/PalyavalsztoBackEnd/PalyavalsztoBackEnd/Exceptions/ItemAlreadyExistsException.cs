﻿namespace PalyavalsztoBackEnd.Exceptions;

public class ItemAlreadyExistsException : Exception
{

}