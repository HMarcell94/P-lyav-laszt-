﻿namespace PalyavalsztoBackEnd.Exceptions;

public class BadUsernameOrPasswordException : Exception
{
}
