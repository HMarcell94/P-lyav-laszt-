﻿namespace PalyavalsztoBackEnd.Exceptions
{
    public class RegistrationUnsuccessException : Exception
    {
        public IEnumerable<string> MissingMembers { get; private set; }
        public RegistrationUnsuccessException(IEnumerable<string> missingMembers)
        {
            MissingMembers = missingMembers;
        }
    }
}
