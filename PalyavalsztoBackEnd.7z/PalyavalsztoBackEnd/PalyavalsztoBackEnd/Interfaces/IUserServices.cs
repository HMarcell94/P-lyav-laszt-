﻿using DB_Module.Models;

namespace PalyavalasztoBackEnd.Interfaces
{
    public interface IUserService
    {
        Task AddUser(User user);

        User GetUser(Guid id);

        User[] GetAllUsers();

        Task UpdateUser(User user);

        Task DisableUser(Guid id);

        Task EnableUser(Guid id);
    }
}
