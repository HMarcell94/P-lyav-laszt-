﻿namespace PalyavalsztoBackEnd.Controllers
{
    public class AuthController
    {
    }
}
