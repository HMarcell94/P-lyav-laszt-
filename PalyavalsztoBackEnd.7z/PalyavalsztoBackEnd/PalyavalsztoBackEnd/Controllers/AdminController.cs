﻿namespace PalyavalsztoBackEnd.Controllers
{
    public class AdminController
    {
    }
}
