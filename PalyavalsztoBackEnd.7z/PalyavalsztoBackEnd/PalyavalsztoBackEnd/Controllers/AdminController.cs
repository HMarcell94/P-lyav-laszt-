﻿using DB_Module;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using Table = DB_Module.Models;

namespace PalyavalasztoBackEnd.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize("Admin")]
    [Authorize("TableOperator")]

    public class AdminController: ControllerBase
    {
        private readonly SQL _sql;
        _userService


    }



}