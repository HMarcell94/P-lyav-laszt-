﻿namespace DB_Module.Enums
{
    public enum ESettingType
    {
        String,
        Integer,
        Boolean,
        DateTime
    }
}
