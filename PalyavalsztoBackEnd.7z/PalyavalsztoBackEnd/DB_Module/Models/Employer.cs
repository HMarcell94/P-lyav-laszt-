﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_Module.Models
{
    [Table("employers")]
    public class Employer
    {
        [Key]
        [Required]
        public int EmployerID { get; set; }
        [Required]
        public int? UserID { get; set; }
        [Required]
        public User user { get; set; }
        [Required]
        public string CompanyName { get; set; }
        [Required]
        public string CompanyDescription { get; set; }

        public byte[] CompanyLogo { get; set; }

        public ICollection<job> jobs { get; set; }
    }
}
