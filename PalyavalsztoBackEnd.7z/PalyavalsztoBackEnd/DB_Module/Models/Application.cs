﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_Module.Models
{
    [Table("applications")]
    public class Application
    {
        
        [Key]
        [Required]
        public int ApplicationID { get; set; }
        [Required]
        public int? JobID { get; set; }
        [Required]
        public job job { get; set; }

        [Required]
        public int? EmployeeID { get; set; }

        [Required]
        public Employee employee { get; set; }

        [Required]
        public DateTime? ApplicationDate { get; set; }

        public string ApplicationStatus { get; set; }
    }
}
