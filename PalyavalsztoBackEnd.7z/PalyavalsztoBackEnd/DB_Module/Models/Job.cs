﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace DB_Module.Models
{
    [Table("jobs")]
    public class job
    {
        [Key]
        [Required]
        public int JobID { get; set; }
        [Required]
        public int? EmployerID { get; set; }
        [Required]
        public Employer employer { get; set; }
        [Required]
        public string JobTitle { get; set; }
        [Required]
        public string JobDescription { get; set; }
        [Required]
        public string JobRequirements { get; set; }
        [Required]
        public string JobLocation { get; set; }
        [Required]
        public decimal? JobSalary { get; set; }

        public ICollection<Application> applications { get; set; }
    }
}
