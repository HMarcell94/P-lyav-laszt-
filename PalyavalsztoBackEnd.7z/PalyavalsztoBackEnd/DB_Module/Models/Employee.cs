﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace DB_Module.Models
{
    [Table("employees")]
    public class Employee
    {
        [Key]
        [Required]
        public int EmployeeID { get; set; }
        [Required]
        public int? UserID { get; set; }
        [Required]
        public User user { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string ContactNumber { get; set; }
      
        public byte[] Portfolio { get; set; }

        public byte[] Resume { get; set; }

        public ICollection<Application> applications { get; set; }

    }
}
