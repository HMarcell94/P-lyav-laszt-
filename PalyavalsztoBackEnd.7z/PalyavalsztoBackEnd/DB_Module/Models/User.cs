﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_Module.Models
{
    [Table("users")]
    public class User
    {
        [Key]
        [Required]
        public int UserID { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string Email { get; set; }

        public byte[] ProfilePicture { get; set; }

        public int? RoleID { get; set; }

        public Role role { get; set; }

        public ICollection<Employee> employees { get; set; }

        public ICollection<Employer> employers { get; set; }
    }
}
