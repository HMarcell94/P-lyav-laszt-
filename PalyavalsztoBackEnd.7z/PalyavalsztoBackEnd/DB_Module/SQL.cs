﻿using DB_Module.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_Module
{
    public class SQL : DbContext
    {

        public static string connectionString { get; set; }

        public SQL() : base(new DbContextOptionsBuilder().UseSqlServer(connectionString).Options)
        { }
        public SQL(DbContextOptions options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }
          public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }

        public DbSet<job> Jobs { get; set; }
           
        public DbSet<Employee> Employees { get; set; }  
        public DbSet<Employer> Employers { get; set; }

        public DbSet <Application> Applications { get; set; }   

        }
        }
