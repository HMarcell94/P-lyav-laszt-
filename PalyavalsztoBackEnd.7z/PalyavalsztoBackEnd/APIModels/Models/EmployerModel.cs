﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIModels.Models
{
     public class EmployerModel
    {
        public int EmployerID { get; set; }

        public int? UserID { get; set; }

        public UserModel user { get; set; }

        public string CompanyName { get; set; }

        public string CompanyDescription { get; set; }

        public byte[] CompanyLogo { get; set; }

        public ICollection<JobModel> jobs { get; set; }

    }
}
