﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIModels.Models
{
    public class applications
    {
        public int ApplicationID { get; set; }

        public int JobID { get; set; }

        public job job { get; set; }

        public int EmployeeID { get; set; }

        public string employee { get; set; }

        public DateTime ApplicationDate { get; set; }

        public bool ApplicationStatus { get; set; }

    }
}

    

