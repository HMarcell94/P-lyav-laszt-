﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIModels.Models
{
    public class UserModel
    {
        public int UserID { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public string Email { get; set; }

        public byte[] ProfilePicture { get; set; }

        public int? RoleID { get; set; }

        public RoleModel role { get; set; }

        public ICollection<EmployeeModel> employees { get; set; }

        public ICollection<EmployerModel> employers { get; set; }

    }
}
