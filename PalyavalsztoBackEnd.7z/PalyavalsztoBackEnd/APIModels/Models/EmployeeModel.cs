﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace APIModels.Models
{
    public class EmployeeModel
    {
        public int EmployeeID { get; set; }

        public int? UserID { get; set; }

        public UserModel user { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string ContactNumber { get; set; }

        public byte[] Portfolio { get; set; }
        public byte[] Resume { get; set; }

        public ICollection<applicationsModel> applications { get; set; }
    }
}
